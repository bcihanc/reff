//List<CityModel> getCitiesFromCountry(CountryModel country) {
//  final cities = country.cities.map((city) {
//    return CityModel(
//      countryCode: country.code,
//      countryName: country.name,
//      name: city,
//      langCode: country.code,
//      utc: country.utc,
//    );
//  }).toList();
//
//  return cities;
//}
